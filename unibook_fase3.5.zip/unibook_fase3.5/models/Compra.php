<?php

class Compra
{

    private $conexion;


    public function __construct($conexion)
    {
        $this->conexion = $conexion;
    }


    public function crear(
        $libro_id,
        $comprador_id,
        $vendedor_id,
        $precio,
        $metodo_pago
    ){

        $sql = "INSERT INTO compras
                (
                    libro_id,
                    comprador_id,
                    vendedor_id,
                    precio,
                    metodo_pago
                )
                VALUES (?, ?, ?, ?, ?)";

        $stmt = $this->conexion->prepare($sql);

        if(!$stmt){
            return false;
        }

        $stmt->bind_param(
            "iiids",
            $libro_id,
            $comprador_id,
            $vendedor_id,
            $precio,
            $metodo_pago
        );

        $ok = $stmt->execute();

        $id = $this->conexion->insert_id;

        $stmt->close();

        return $ok ? $id : false;
    }


    public function obtenerDetalleParaUsuario(
        $compra_id,
        $usuario_id
    ){

        $sql = "SELECT
                    c.id,
                    c.estado,
                    c.precio,
                    c.metodo_pago,
                    c.fecha_compra,
                    c.fecha_actualizacion,

                    l.id AS libro_id,
                    l.titulo,
                    l.autor,
                    l.imagen,
                    l.estado_disponibilidad,

                    comp.id AS comprador_id,
                    comp.nombre AS comprador_nombre,
                    comp.apellido AS comprador_apellido,

                    vend.id AS vendedor_id,
                    vend.nombre AS vendedor_nombre,
                    vend.apellido AS vendedor_apellido,
                    vend.correo AS vendedor_correo

                FROM compras c

                INNER JOIN libros l
                    ON l.id = c.libro_id

                INNER JOIN usuarios comp
                    ON comp.id = c.comprador_id

                INNER JOIN usuarios vend
                    ON vend.id = c.vendedor_id

                WHERE c.id = ?
                AND (
                    c.comprador_id = ?
                    OR c.vendedor_id = ?
                )";

        $stmt = $this->conexion->prepare($sql);

        if(!$stmt){
            return null;
        }

        $stmt->bind_param(
            "iii",
            $compra_id,
            $usuario_id,
            $usuario_id
        );

        $stmt->execute();

        $resultado = $stmt->get_result();

        $fila = $resultado->fetch_assoc();

        $stmt->close();

        return $fila;
    }


    public function obtenerPorComprador($usuario_id)
    {

        $sql = "SELECT
                    c.id,
                    c.estado,
                    c.precio,
                    c.metodo_pago,
                    c.fecha_compra,

                    l.id AS libro_id,
                    l.titulo,
                    l.autor,
                    l.imagen,
                    l.universidad,
                    l.carrera,
                    l.semestre,

                    u.nombre AS vendedor_nombre,
                    u.apellido AS vendedor_apellido

                FROM compras c

                INNER JOIN libros l
                    ON l.id = c.libro_id

                INNER JOIN usuarios u
                    ON u.id = c.vendedor_id

                WHERE c.comprador_id = ?

                ORDER BY c.fecha_compra DESC";

        $stmt = $this->conexion->prepare($sql);

        if(!$stmt){
            return [];
        }

        $stmt->bind_param(
            "i",
            $usuario_id
        );

        $stmt->execute();

        $resultado = $stmt->get_result();

        $compras = [];

        while($fila = $resultado->fetch_assoc()){
            $compras[] = $fila;
        }

        $stmt->close();

        return $compras;
    }


    public function obtenerPorVendedor($usuario_id)
    {

        $sql = "SELECT
                    c.id,
                    c.estado,
                    c.precio,
                    c.metodo_pago,
                    c.fecha_compra,

                    l.id AS libro_id,
                    l.titulo,
                    l.autor,
                    l.imagen,
                    l.universidad,
                    l.carrera,
                    l.semestre,

                    u.nombre AS comprador_nombre,
                    u.apellido AS comprador_apellido

                FROM compras c

                INNER JOIN libros l
                    ON l.id = c.libro_id

                INNER JOIN usuarios u
                    ON u.id = c.comprador_id

                WHERE c.vendedor_id = ?

                ORDER BY c.fecha_compra DESC";

        $stmt = $this->conexion->prepare($sql);

        if(!$stmt){
            return [];
        }

        $stmt->bind_param(
            "i",
            $usuario_id
        );

        $stmt->execute();

        $resultado = $stmt->get_result();

        $ventas = [];

        while($fila = $resultado->fetch_assoc()){
            $ventas[] = $fila;
        }

        $stmt->close();

        return $ventas;
    }


    /*
     * FASE 3.5
     *
     * Confirma una operación pendiente.
     * Solo el vendedor asociado puede hacerlo.
     */
    public function confirmarVenta($compra_id, $vendedor_id)
    {

        $sql = "UPDATE compras
                SET estado = 'confirmada',
                    fecha_actualizacion = NOW()
                WHERE id = ?
                AND vendedor_id = ?
                AND estado = 'pendiente'";

        $stmt = $this->conexion->prepare($sql);

        if(!$stmt){
            return false;
        }

        $stmt->bind_param(
            "ii",
            $compra_id,
            $vendedor_id
        );

        $stmt->execute();

        $afectadas = $stmt->affected_rows;

        $stmt->close();

        return $afectadas > 0;
    }


    /*
     * FASE 3.5
     *
     * Cancela una operación pendiente.
     * Solo el vendedor asociado puede hacerlo.
     */
    public function cancelarVenta($compra_id, $vendedor_id)
    {

        $sql = "UPDATE compras
                SET estado = 'cancelada',
                    fecha_actualizacion = NOW()
                WHERE id = ?
                AND vendedor_id = ?
                AND estado = 'pendiente'";

        $stmt = $this->conexion->prepare($sql);

        if(!$stmt){
            return false;
        }

        $stmt->bind_param(
            "ii",
            $compra_id,
            $vendedor_id
        );

        $stmt->execute();

        $afectadas = $stmt->affected_rows;

        $stmt->close();

        return $afectadas > 0;
    }

}